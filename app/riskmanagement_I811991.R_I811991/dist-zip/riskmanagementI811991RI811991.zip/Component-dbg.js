sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("riskmanagementI811991.RI811991.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);