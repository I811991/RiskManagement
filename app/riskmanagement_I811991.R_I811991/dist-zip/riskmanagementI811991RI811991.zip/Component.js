sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("riskmanagementI811991.RI811991.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map